# Project 23 - Supply Mission: Part 2
Made by Rishi Venkatesh

Link: https://ethyx.github.io/PRO-C23/
